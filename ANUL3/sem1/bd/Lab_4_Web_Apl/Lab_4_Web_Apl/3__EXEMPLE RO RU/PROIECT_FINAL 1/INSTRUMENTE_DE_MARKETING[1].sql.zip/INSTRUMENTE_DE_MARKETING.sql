-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 27, 2012 at 03:40 PM
-- Server version: 5.1.40
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `INSTRUMENTE_DE_MARKETING`
--

-- --------------------------------------------------------

--
-- Table structure for table `AGENTUL_ECONOMIC`
--

CREATE TABLE IF NOT EXISTS `AGENTUL_ECONOMIC` (
  `ID_AGE` int(3) NOT NULL AUTO_INCREMENT,
  `NUMELE_AGENTULUI` varchar(25) NOT NULL,
  PRIMARY KEY (`ID_AGE`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `AGENTUL_ECONOMIC`
--

INSERT INTO `AGENTUL_ECONOMIC` (`ID_AGE`, `NUMELE_AGENTULUI`) VALUES
(1, 'JLC');

-- --------------------------------------------------------

--
-- Table structure for table `APLICAREA_INSTRUMENTELOR`
--

CREATE TABLE IF NOT EXISTS `APLICAREA_INSTRUMENTELOR` (
  `ID_CLIENT` int(3) NOT NULL,
  `ID_INSTRUMENT` int(3) NOT NULL,
  `DATA` date NOT NULL,
  `FEEDBACK` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `APLICAREA_INSTRUMENTELOR`
--

INSERT INTO `APLICAREA_INSTRUMENTELOR` (`ID_CLIENT`, `ID_INSTRUMENT`, `DATA`, `FEEDBACK`) VALUES
(1, 1, '2012-04-03', 'SPORIREA VINZARILOR'),
(3, 2, '2012-05-01', 'Obitinerea fidelitatii'),
(4, 3, '2012-05-09', 'Fara schimbari.');

-- --------------------------------------------------------

--
-- Table structure for table `CLIENT`
--

CREATE TABLE IF NOT EXISTS `CLIENT` (
  `ID_AGE` int(3) NOT NULL,
  `ID_DP` int(3) NOT NULL,
  `ID_SDP` int(3) NOT NULL,
  `ID_CLIENT` int(3) NOT NULL,
  `NUME_CLIENT` varchar(25) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `ID_PROD` int(3) NOT NULL,
  `VENITUL` int(5) NOT NULL,
  `PERIOADA_DE_TIMP` date NOT NULL,
  `VOLUMUL_ACHIZITIILOR` int(4) NOT NULL,
  PRIMARY KEY (`ID_CLIENT`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `CLIENT`
--

INSERT INTO `CLIENT` (`ID_AGE`, `ID_DP`, `ID_SDP`, `ID_CLIENT`, `NUME_CLIENT`, `ID_PROD`, `VENITUL`, `PERIOADA_DE_TIMP`, `VOLUMUL_ACHIZITIILOR`) VALUES
(1, 1, 4, 2, 'Client1', 6, 6775, '2010-04-15', 21),
(1, 1, 3, 5, 'Client4', 8, 232, '2012-06-05', 12),
(1, 2, 7, 3, 'Client2', 5, 5467, '2012-06-13', 12),
(1, 1, 3, 4, 'Client3', 4, 35000, '2012-03-12', 13),
(1, 3, 6, 1, 'Client5', 20, 3453, '2012-06-18', 32);

-- --------------------------------------------------------

--
-- Table structure for table `Concurenti`
--

CREATE TABLE IF NOT EXISTS `Concurenti` (
  `ID_DP` int(3) NOT NULL,
  `ID_SDP` int(3) NOT NULL,
  `ID_AGEP` int(3) NOT NULL AUTO_INCREMENT,
  `NUMELE_AGEMTULUI_CONCURENT` varchar(25) NOT NULL,
  PRIMARY KEY (`ID_AGEP`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `Concurenti`
--

INSERT INTO `Concurenti` (`ID_DP`, `ID_SDP`, `ID_AGEP`, `NUMELE_AGEMTULUI_CONCURENT`) VALUES
(1, 2, 1, 'LAPMOL'),
(1, 5, 2, 'LACTIS-ALBA'),
(3, 6, 3, 'ZIBELIN'),
(1, 7, 4, 'lASKA_MOLL');

-- --------------------------------------------------------

--
-- Table structure for table `DOMENIU_DE_PRODUCERE`
--

CREATE TABLE IF NOT EXISTS `DOMENIU_DE_PRODUCERE` (
  `ID_AGE` int(3) NOT NULL,
  `ID_DP` int(3) NOT NULL AUTO_INCREMENT,
  `NUMELE_DOMENIULUI` varchar(25) NOT NULL,
  PRIMARY KEY (`ID_DP`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `DOMENIU_DE_PRODUCERE`
--

INSERT INTO `DOMENIU_DE_PRODUCERE` (`ID_AGE`, `ID_DP`, `NUMELE_DOMENIULUI`) VALUES
(1, 1, 'LACTATE'),
(1, 2, 'Sucuri'),
(1, 3, 'Conserve'),
(1, 4, 'Domeniu4');

-- --------------------------------------------------------

--
-- Table structure for table `INSTRUMENTILE`
--

CREATE TABLE IF NOT EXISTS `INSTRUMENTILE` (
  `ID_INSTRUMENT` int(3) NOT NULL AUTO_INCREMENT,
  `NUME_INSTRUMENT` varchar(25) NOT NULL,
  `CARACTERISTICILE` text NOT NULL,
  PRIMARY KEY (`ID_INSTRUMENT`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `INSTRUMENTILE`
--

INSERT INTO `INSTRUMENTILE` (`ID_INSTRUMENT`, `NUME_INSTRUMENT`, `CARACTERISTICILE`) VALUES
(1, 'REDUCERE', 'Se fac reduceri sa se obtie fidelitatea clientilor,sai motivezi la marirea cumparaturilo,de sarbatori.'),
(2, 'CADOURI', 'Motivarea clientilor sa procure un anumit produs.'),
(3, 'LOTERIE', 'Oganizarea unei loterei cu sporirea interesului catre un anumit produs.');

-- --------------------------------------------------------

--
-- Table structure for table `PIATA_SI_AGENTII_ECONOMICI_CONCURENTI`
--

CREATE TABLE IF NOT EXISTS `PIATA_SI_AGENTII_ECONOMICI_CONCURENTI` (
  `ID_AGEP` int(3) NOT NULL,
  `ID_DP` int(3) NOT NULL,
  `ID_SDP` int(3) NOT NULL,
  `ID_PROD` int(4) NOT NULL,
  `PRETUL_PE_PIATA_INTERNA_PE_UNITATE` float NOT NULL,
  `PRETUL_PE_PIATA_EXTERNA_PE_UNITATE` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `PIATA_SI_AGENTII_ECONOMICI_CONCURENTI`
--

INSERT INTO `PIATA_SI_AGENTII_ECONOMICI_CONCURENTI` (`ID_AGEP`, `ID_DP`, `ID_SDP`, `ID_PROD`, `PRETUL_PE_PIATA_INTERNA_PE_UNITATE`, `PRETUL_PE_PIATA_EXTERNA_PE_UNITATE`) VALUES
(1, 1, 3, 1, 8.1, 12),
(1, 1, 5, 5, 11, 14),
(2, 1, 2, 12, 10.5, 13),
(4, 1, 7, 2, 23, 34);

-- --------------------------------------------------------

--
-- Table structure for table `PRODUSELE_PRODUSE`
--

CREATE TABLE IF NOT EXISTS `PRODUSELE_PRODUSE` (
  `ID_AGE` int(3) NOT NULL,
  `ID_DP` int(3) NOT NULL,
  `ID_SDP` int(3) NOT NULL,
  `ID_PROD` int(4) NOT NULL,
  `COSTUL_SINECOSTUL` float NOT NULL,
  `VOLUMUL_PRODUSULUI` int(5) NOT NULL,
  `PRETUL_TOTAL_4*5` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `PRODUSELE_PRODUSE`
--

INSERT INTO `PRODUSELE_PRODUSE` (`ID_AGE`, `ID_DP`, `ID_SDP`, `ID_PROD`, `COSTUL_SINECOSTUL`, `VOLUMUL_PRODUSULUI`, `PRETUL_TOTAL_4*5`) VALUES
(1, 1, 1, 1, 6.15, 1, 6.15),
(1, 1, 3, 2, 6.95, 1, 6.95),
(1, 1, 3, 3, 4, 1, 6),
(1, 1, 3, 4, 8.65, 1, 8.65),
(1, 1, 5, 5, 12.65, 300, 15),
(1, 1, 1, 6, 6.4, 1, 6.4),
(1, 1, 1, 9, 9.6, 0, 11.6),
(1, 3, 6, 20, 32, 2, 64);

-- --------------------------------------------------------

--
-- Table structure for table `PRODUSUL`
--

CREATE TABLE IF NOT EXISTS `PRODUSUL` (
  `ID_AGE` int(3) NOT NULL,
  `ID_DP` int(3) NOT NULL,
  `ID_SDP` int(3) NOT NULL,
  `ID_PROD` int(4) NOT NULL AUTO_INCREMENT,
  `NUMELE_PRODUSULUI` varchar(25) NOT NULL,
  PRIMARY KEY (`ID_PROD`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `PRODUSUL`
--

INSERT INTO `PRODUSUL` (`ID_AGE`, `ID_DP`, `ID_SDP`, `ID_PROD`, `NUMELE_PRODUSULUI`) VALUES
(1, 1, 3, 1, 'Lapte,1.5%,1L'),
(1, 1, 3, 2, 'Lapte,2.5%,1L'),
(1, 1, 3, 3, 'Lapte,2.5,0.5L'),
(1, 1, 3, 4, 'Lapte,3.5%,1L'),
(1, 1, 5, 5, 'Smintina,25%,300gr'),
(1, 1, 1, 6, 'Iaurt DELICATO piersic'),
(1, 1, 1, 7, 'Iaurt DELICATO mango'),
(1, 1, 1, 8, 'Iaurt DELICATO zamoz'),
(1, 1, 1, 9, 'Iaurt BIO ANANAS'),
(1, 1, 1, 10, 'Iaurt BIO BANAN'),
(1, 1, 2, 11, 'Chefir 2.5%'),
(1, 1, 2, 12, 'Chefir 0%,1L'),
(1, 1, 2, 13, 'Chefir 1%,0.5L'),
(1, 1, 2, 14, 'Chefir 2.5% tetrapak 0.5L'),
(1, 1, 5, 15, 'Smintina 10%,0.5L'),
(1, 1, 5, 16, 'Smintina 35%,0.5L'),
(1, 1, 5, 17, 'Simintina 10%,400gr'),
(1, 1, 4, 18, 'Brinzica mic-vis cocos'),
(1, 1, 4, 19, 'Brinzica armonia ciuperci'),
(1, 3, 6, 20, 'PATEU DE GAINA'),
(1, 3, 6, 21, 'PATEU DE PORC');

-- --------------------------------------------------------

--
-- Table structure for table `SUBDOMENIU_DE_PRODUCERE`
--

CREATE TABLE IF NOT EXISTS `SUBDOMENIU_DE_PRODUCERE` (
  `ID_AGE` int(3) NOT NULL,
  `ID_DP` int(3) NOT NULL,
  `ID_SDP` int(3) NOT NULL AUTO_INCREMENT,
  `NUME_SUBDOMENIU` varchar(30) NOT NULL,
  PRIMARY KEY (`ID_SDP`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `SUBDOMENIU_DE_PRODUCERE`
--

INSERT INTO `SUBDOMENIU_DE_PRODUCERE` (`ID_AGE`, `ID_DP`, `ID_SDP`, `NUME_SUBDOMENIU`) VALUES
(1, 1, 1, 'IAURTURI'),
(1, 1, 2, 'CHEFIR'),
(1, 1, 3, 'LAPTE'),
(1, 1, 4, 'BRINZELE'),
(1, 1, 5, 'SMINTINA'),
(1, 3, 6, 'Pateuri'),
(1, 3, 7, 'SIPROT');
