a, b, c, d = 1, 2, 3, 4
if a == b:
    print("a = b")
elif a == c:
    print("a == c")
elif a == d:
    print("a == d")
elif b == c:
    print("b == c")
elif b == d:
    print("b == d")
elif c == d:
    print("c == d")
