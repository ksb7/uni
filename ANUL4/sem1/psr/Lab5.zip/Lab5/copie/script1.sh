#!/bin/bash
echo "PID-ul meu este $$"

