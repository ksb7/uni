#!/bin/bash
case $1 in
    1) echo "ianuarie" ;;
    2) echo "februarie" ;;
    3) echo "martie" ;;
    4) echo "aprilie" ;;
    5) echo "mai" ;;
    6) echo "iunie" ;;
    7) echo "iulie" ;;
    8) echo "august" ;;
    9) echo "septembrie" ;;
    10) echo "octombrie" ;;
    11) echo "noiembrie" ;;
    12) echo "decembrie" ;;
    *) echo "Numar invalid (1-12)" ;;
esac
