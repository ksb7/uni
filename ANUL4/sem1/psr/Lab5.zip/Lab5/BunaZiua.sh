#!/bin/bash
echo Buna ziua !
